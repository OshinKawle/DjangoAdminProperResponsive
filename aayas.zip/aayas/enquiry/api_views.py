from rest_framework.generics import CreateAPIView
from .models import Enquiry ,CareerEnquiry

from .serializers import EnquirySerializer ,CareerEnquirySerializer

class EnquiryListAPI(CreateAPIView):
    queryset = Enquiry.objects.all()
    serializer_class = EnquirySerializer


# class CareerEnquiryListAPI(CreateAPIView):
#     print('ssssssssssss')
#     queryset = CareerEnquiry.objects.all()
#     serializer_class = CareerEnquirySerializer

from rest_framework.parsers import MultiPartParser, FormParser

class CareerEnquiryListAPI(CreateAPIView):
    queryset = CareerEnquiry.objects.all()
    serializer_class = CareerEnquirySerializer
    parser_classes = (MultiPartParser, FormParser)