
from django.urls import path
from .api_views import EnquiryListAPI ,CareerEnquiryListAPI

urlpatterns = [
    path('add-cities/', EnquiryListAPI.as_view(), name='api_city_post'),
    path('add-career/', CareerEnquiryListAPI.as_view(), name='api_career_post'),
]
