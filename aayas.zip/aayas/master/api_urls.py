from django.urls import path
from .api_views import CityListAPI

urlpatterns = [
    path('cities/', CityListAPI.as_view(), name='api_city_list'),
]
